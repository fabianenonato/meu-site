package kdc.cipher;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

public class AES 
{
	public static byte[] cipher(String text, String key) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException, UnsupportedEncodingException
	{
		return cipher(text.getBytes(), key);
	}
	
	public static byte[] cipher(byte[] text, String key) 
			throws IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException, UnsupportedEncodingException, InvalidKeyException
	{
		Key privateKey = new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), "AES");
		
		Cipher cifrador = Cipher.getInstance("AES");
		cifrador.init(Cipher.ENCRYPT_MODE, privateKey);
		byte[] textoCifrado = cifrador.doFinal(text);
		return textoCifrado;
	}	
	
	public static String decipher(byte[] text, String key) 
			throws IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException, UnsupportedEncodingException, InvalidKeyException
	{
	  	 Key privateKey = 
	  			 new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), "AES");
		 Cipher decifrador = Cipher.getInstance("AES");
		 decifrador.init(Cipher.DECRYPT_MODE, privateKey);
    	 byte[] textoDecifrado = decifrador.doFinal(text);
    	 return new String(textoDecifrado);
	}	
	
}