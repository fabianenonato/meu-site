package kdc.entity;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Logger;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class Alice extends Client{

	private static final Logger logger = Logger.getLogger(Alice.class.toString());

	int nonce;
	
	public Alice() {
		super("6yi5o45ui4ou1k56");
	}
	
	public byte[] getNonce(byte[] encryptedKeySession) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException, UnsupportedEncodingException {
		sessionKey = decipherMaster(encryptedKeySession);
		logger.info(String.format("Recevived session key %s", sessionKey));
		
		nonce = ThreadLocalRandom.current().nextInt(1, 100);
		logger.info(String.format("Generated nonce %d", nonce));
		
		return cipherSession(Integer.toString(nonce));
	}
	
	public void confirmNonce(byte[] encryptedNonce) throws NumberFormatException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException, UnsupportedEncodingException {
		int calculatedNonce = Integer.parseInt(decipherSession(encryptedNonce));
		
		if (calculatedNonce == (nonce * 2)) {
			logger.info("Nonce response is valid");
		} else {
			logger.info("Nonce response is invalid");
		}
		
	}

}
