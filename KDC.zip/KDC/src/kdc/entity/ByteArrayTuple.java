package kdc.entity;

public class ByteArrayTuple {

	private byte[] first;
	private byte[] second;
	
	public ByteArrayTuple(byte[] first, byte[] second) {
		this.first = first;
		this.second = second;
	}

	public byte[] getFirst() {
		return first;
	}

	public byte[] getSecond() {
		return second;
	}
	
}
