package kdc.entity;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import kdc.cipher.AES;

public class Client {

	private String masterKey;
	protected String sessionKey;
	
	public Client(String masterKey) {
		this.masterKey = masterKey;
	}
	
	protected byte[] cipherSession(String text) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException, UnsupportedEncodingException {
		return AES.cipher(text, sessionKey);
	}
	
	protected String decipherSession(byte[] text) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException, UnsupportedEncodingException {
		return AES.decipher(text, sessionKey);
	}
	
	protected byte[] cipherMaster(String text) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException, UnsupportedEncodingException {
		return AES.cipher(text, masterKey);
	}
	
	protected String decipherMaster(byte[] text) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException, UnsupportedEncodingException {
		return AES.decipher(text, masterKey);
	}
	
}
