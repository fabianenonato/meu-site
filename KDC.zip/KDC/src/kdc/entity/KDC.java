package kdc.entity;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import kdc.cipher.AES;
import kdc.string.RandomKey;

public class KDC {
	
	private static final Logger logger = Logger.getLogger(KDC.class.toString());
	
	private RandomKey keyGenerator;
	
	private Map<String, String> masterKeys;
		
	public KDC() {
		keyGenerator = new RandomKey(16);
		masterKeys = new HashMap<>();
		
		masterKeys.put("alice", "6yi5o45ui4ou1k56");
		masterKeys.put("bob", 	"1a2e3f8g4j8f15h7");
	}
	
	public ByteArrayTuple getSessionKey(String from, byte[] encryptedFrom, byte[] encryptedToWhom) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException, UnsupportedEncodingException {
		String masterKey = masterKeys.get(from);
		
		String fromConfirmation = AES.decipher(encryptedFrom, masterKey);
	
		if (!fromConfirmation.equals(from)) {
			throw new RuntimeException("Your identity is not valid");
		}

		String toWhom = AES.decipher(encryptedToWhom, masterKey);
		
		String sessionKey = keyGenerator.nextKey();
		
		String toWhomKey = masterKeys.get(toWhom);
		
		logger.info(String.format("Received message from %s to %s", from, toWhom));
		
		return new ByteArrayTuple(AES.cipher(sessionKey, masterKey), AES.cipher(sessionKey, toWhomKey));
	}
	
}
