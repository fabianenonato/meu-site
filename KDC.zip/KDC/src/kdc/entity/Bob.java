package kdc.entity;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Logger;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class Bob extends Client {

	private static final Logger logger = Logger.getLogger(Bob.class.toString());
	
	private KDC kdc;
	private Alice alice;
	
	public Bob() {
		super("1a2e3f8g4j8f15h7");
		kdc = new KDC();
		alice = new Alice();
	}
	
	public void talkToAlice() throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException, UnsupportedEncodingException {
		ByteArrayTuple tuple = kdc.getSessionKey("bob", cipherMaster("bob"), cipherMaster("alice"));		
		
		sessionKey = decipherMaster(tuple.getFirst());
		
		logger.info(String.format("Recevived session key %s", sessionKey));
		
		logger.info("Requesting nonce to alice");
		byte[] encryptedNonce = alice.getNonce(tuple.getSecond());
		
		int nonce = Integer.parseInt(decipherSession(encryptedNonce));
		logger.info(String.format("Received nonce %d", nonce));
		
		int nonceResponse = nonce * 2;
		logger.info(String.format("Confirming nonce %d", nonceResponse));
		alice.confirmNonce(cipherSession(Integer.toString(nonceResponse)));		
	}	
	
}
